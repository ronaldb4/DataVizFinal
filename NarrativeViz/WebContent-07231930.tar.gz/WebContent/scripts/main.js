// significant borrowing and adaptation from https://www.visualcinnamon.com/2015/07/voronoi.html
// simple-statistics.js library used for regression line calculation

var scatterHeight = 600;
var scatterWidth = 600;
function init() {
	var showSection1 = function(){
		removeAxes(); showYear(years[years.length-1]);
	}
	var showSection2 = function(){
		addAxes(); showYear(years[years.length-2]);
	}
	var showSection3 = function(){
		showYear(years[years.length-3]);
	}
	var showSection4 = function(){
		showYear(years[years.length-4]);
	}
	var showSection5 = function(){
		showYear(years[years.length-5]);
	}
	
	/*
	 * set-up observer for modifying the scatter based on scroll
	 */
	const sections = document.querySelectorAll(".triggerText");
	const sectionObserver = new IntersectionObserver(
			function(entries, observer){
				entries.forEach(entry => {
					if (entry.isIntersecting){
console.log(entry.target.id)
						switch(entry.target.id){
							case 'section1' : showSection1(); break; 
							case 'section2' : showSection2(); break; 
							case 'section3' : showSection3(); break; 
							case 'section4' : showSection4(); break; 
							case 'section5' : showSection5(); break; 
						}
					}
				})
			}
			,{
				root: null,
				threshold: 0,
				rootMargin:"-300px"
			}
		)
	sections.forEach(section => {
		sectionObserver.observe(section);
	})
	

	/*
	 * set heights of scatterplot and text area
	 */
    scatterHeight = (document.getElementById("scatterplot").clientHeight) -60;
    scatterWidth = document.getElementById("scatterplot").clientWidth;
    
    document.querySelector(".vizText").setAttribute("style","height:"+(scatterHeight-50)+"px");
//console.log( document.querySelector(".vizText").style.height)    

    /*
     * create the SVG and axes
     */
    buildPlotSpace();
}

/*
 *  utility functions 
 */
var showYear = function(data){
	loadYear(data) ; 
	plotRegressionLine(); 
	showScatter(); 
	showColor(); 
	addPopovers()
}

var calcAxisVal = function(logMethod, d, src, zeroVal){
  if (d[src]===null)
    return zeroVal;
  var result = logMethod(d[src]);
  if (isNaN(result))
    return zeroVal;
  return result;
}

var getMinMax = function(arr,arr2,yearIdx){
    var minVal = Number.MAX_VALUE;
    var maxVal = Number.MIN_VALUE;

    for (var yIdx=0; yIdx<arr.length;yIdx++){
        if (yearIdx!=undefined && yIdx!=yearIdx)
            continue;
        var values=arr[yIdx];
        var values2=arr2[yIdx];
        for (var vIdx=0; vIdx<values.length;vIdx++){
            if (values[vIdx]==null || values2[vIdx]==null)
                continue;
            if (values[vIdx]<minVal)
                minVal = values[vIdx];
            if (values[vIdx]>maxVal)
                maxVal = values[vIdx];
        }
    }
    if (minVal<=0)
        minVal = 0.5;
    return [minVal, maxVal];
}

 var getBin = function(binPoints, value) {
  for (var idx=0;idx<binPoints.length;idx++)
    if (value<binPoints[idx])
      return idx+1;
  return binPoints.length;
}

var simpleBinPoints = function(values, binCount) {
  if (values.length<=(binCount-1))
    return values;

  var binPoint = [];
  var binSize = Math.floor(values.length/binCount);
  var sorted = values.slice().sort(function(a, b){return a-b});
  for (var idx=0; idx<binCount; idx++)
    binPoint[idx] = sorted[(1+idx)*binSize];
  return binPoint;
}

var lineDistance = function(record, regression){
    num = Math.abs(regression.b + regression.m*(calcAxisVal(yearXaxisScale, record, "gdp", 0)) - calcAxisVal(yearYaxisScale, record, "tb", 0))
    den = Math.sqrt(1+Math.pow(regression.m,2))
    return num/den;
}

/*
 * data loader
 */
var yearData = [];
var currentYear;
var plottedPoints;
var regression;
var yearYaxisScale;
var yearXaxisScale;
var loadYear = function(tgtYear){
    currentYear = tgtYear;

    const year = years.indexOf(tgtYear);
    yearYaxisScale  = d3.scaleLog().clamp(true).domain(getMinMax(SH_TBS_INCD,NY_GDP_PCAP_CD,year)).range([(scatterHeight-100),0]);
    yearXaxisScale = d3.scaleLog().clamp(true).domain(getMinMax(NY_GDP_PCAP_CD,SH_TBS_INCD,year)).range([0,(scatterWidth-100)]);

    yearData = [];

    var tbBins = simpleBinPoints(SH_TBS_INCD[year],10);
    var gdpBins = simpleBinPoints(NY_GDP_PCAP_CD[year],10);

    for (var idx=0; idx<countries.length ; idx++){
        var tbIncidence = SH_TBS_INCD[year][idx];
        var gdpPerCap = NY_GDP_PCAP_CD[year][idx];
        yearData[idx]               = countries[idx];
        yearData[idx]["tb"]         = tbIncidence;
        yearData[idx]["tbBin"]      = getBin(tbBins,tbIncidence);
        yearData[idx]["gdp"]        = gdpPerCap;
        yearData[idx]["gdpBin"]     = getBin(gdpBins,gdpPerCap);
        yearData[idx]["popDensity"] = EN_POP_DNST[year][idx];
    }
    plottedPoints = yearData.map(function(d) { return [
                                                            calcAxisVal(yearXaxisScale, d, "gdp", 0),
                                                            calcAxisVal(yearYaxisScale, d, "tb", 0)
                                                        ];})
    regression = ss.linearRegression(plottedPoints);

    var numClose = 0;
    for (var idx = 0; idx< yearData.length;idx++){
        var close = lineDistance(yearData[idx], regression)<=65;
        if (close)
            numClose++;
        yearData[idx]["distance"] = lineDistance(yearData[idx], regression);
        yearData[idx]["closeToMiddle"] = close;
    }
    console.log(numClose/yearData.length)
}


/*
 * chart rendering functions
 */
var scatterYaxisScale;
var scatterXaxisScale;
function buildPlotSpace(){
  scatterYaxisScale  = d3.scaleLog().clamp(true).domain(getMinMax(SH_TBS_INCD,NY_GDP_PCAP_CD)).range([(scatterHeight-100),0]);
  scatterXaxisScale = d3.scaleLog().clamp(true).domain(getMinMax(NY_GDP_PCAP_CD,SH_TBS_INCD)).range([0,(scatterWidth-100)]);

  var svg = d3.select("#scatterplot").append("svg").attr("id", "plotSpace").attr("height", scatterHeight).attr("width", scatterWidth)

  svg.append("g").attr("class", "guideWrapper")
				.attr("transform", "translate(50,50)");

  svg.append("g")
          .attr("id","scatterBody")
          .attr("transform","translate(50,50)");

}

function removeAxes(){
	d3.select("#yAxis").remove();
	d3.select("#yAxisText").remove();
	d3.select("#xAxis").remove();
	d3.select("#xAxisText").remove();
}

function addAxes(){
	var svg = d3.select("#plotSpace");
	if(!d3.select("#yAxis").empty())
		return;
	
	//y-axis
	svg.append("g")
		.attr("id","yAxis")
		.attr("transform","translate(50,50)")
		.attr("fill","none")
		.call(
		  d3.axisLeft(scatterYaxisScale)
		    .tickValues([1,2,5,10, 20, 50, 100,200,500,1000])
		    .tickFormat(d3.format("~s"))
		  );

	// text label for the y-axis
	svg.append("text")
		.attr("id","yAxisText")
		.attr("class","legend")
		.attr("transform", "rotate(-90)")
		.attr("y", 0)
		.attr("x",0 - (scatterHeight / 2))
		.attr("dy", "1em")
		.style("text-anchor", "middle")
		.text("Incidence of tuberculosis (per 100,000 people)");
	
	//x-axis
	svg.append("g")
		.attr("id","xAxis")
		.attr("transform","translate(50,"+(scatterHeight-50)+")")
		.attr("fill","none")
		.call(
		    d3.axisBottom(scatterXaxisScale)
		      .tickValues([200,500,1000,2000,5000,10000,20000,50000,100000,200000])
		      .tickFormat(d3.format("~s"))
		);
	// text label for the x axis
	svg.append("text")
		.attr("id","xAxisText")
		.attr("class","legend")
		.attr("transform",
		    "translate(" + (scatterWidth/2) + "," + (scatterHeight-5) + ")")
		.style("text-anchor", "middle")
		.text("GDP per capita (current US$)");
}

function plotRegressionLine(){
    d3.select("#linearRegressionLine").remove();

    var maxX = Number.MIN_VALUE;
    var minX = Number.MAX_VALUE;
    for (var idx=0;idx<plottedPoints.length;idx++){
        if(plottedPoints[idx][0]>maxX)
            maxX = plottedPoints[idx][0];
        if(plottedPoints[idx][0]<minX)
            minX = plottedPoints[idx][0];
    }

    var regressionLine = ss.linearRegressionLine(regression);
    var svg = d3.select("#plotSpace");
    svg.append("g") .attr("transform", "translate(50,50)")
        .attr("id","linearRegressionLine")
        .append("line")
        .style("stroke","lightgrey")
        .style("stroke-width","2px")
        .style("stroke-opacity",.8)
        .attr("x1", minX)
        .attr("y1", regressionLine(minX))
        .attr("x2", maxX)
        .attr("y2", regressionLine(maxX))
    ;
}

function showColor() {
    d3.select("#scatterBody").selectAll("circle")
        .data(yearData)
              .attr("class" , function(d){
                  return (!d.closeToMiddle) ? "region-"+regionMap[d.region] : "dull" ;
              })
}


function showScatter() {
    //remove existing circles
    d3.select("#scatterBody").selectAll("circle").remove();
    d3.select("#scatterBody").selectAll("text").remove();

    d3.select("#scatterBody").append("text")
        .attr("class","h1")
        .attr("transform", "translate(" + (scatterWidth/2) + ",0)")
        .style("text-anchor", "middle")
        .text(currentYear);

    d3.select("#scatterBody").selectAll("circle")
        .data(yearData)
            .enter()
              .append("circle")
                .attr("id", function(d){ return d.countryCode; })
                .attr("cx", function(d,idx){ return calcAxisVal(scatterXaxisScale, d, "gdp", 0) })
                .attr("cy", function(d,idx){ return calcAxisVal(scatterYaxisScale, d, "tb", (scatterHeight-50)) })
                .attr("r",function(d,idx){ return (d.gdp === null || d.tb === null) ? 0 : 3 ;})
                .attr("data",function(d){ return JSON.stringify(d); })
    ;

}

var addPopovers = function () {
    d3.select("#scatterBody")
        .selectAll("path").remove();

    var voronoi = d3.voronoi()
        .x(function(d){ return calcAxisVal(scatterXaxisScale, d, "gdp", 0) })
        .y(function(d){ return calcAxisVal(scatterYaxisScale, d, "tb", (scatterHeight-50)) })
        .extent([[0, 0], [scatterWidth-100, scatterHeight-100]]);

    d3.select("#scatterBody")
        .selectAll("path")
            .data(voronoi.polygons(yearData)) //Use vononoi() with your dataset inside
                .enter()
                    .append("path")
                    .style("stroke", "none")
                    .style("fill", "none")
                    .style("pointer-events", "all")
                    .attr("d", function(d, i) { return (d==null) ? "M0,0Z" : "M" + d.join("L") + "Z"; })
                    .on("mouseover", showTooltip)
                    .on("mouseout",  hideTooltip);
}

var showTooltip = function(d) {
    //get location info for tooltip
    var element = d3.selectAll("#"+d.data.countryCode);
    var x = +element.attr("cx"),
        y = +element.attr("cy"),
        color = element.style("fill");

    //populate tooltip and show
    d3.select("#scatterBody").append("text")
        .attr("id", d.data.countryCode+"-tooltip")
        .attr("x", x+3)
        .attr("y", y-3)
        .attr("class","tooltip")
        .text(d.data.name)
        .style("pointer-events", "none")
        .style("opacity",0)
        .transition().duration(300)
        .style("opacity", 1);

    //draw guidelines
    var wrapper = d3.selectAll(".guideWrapper");
    //vertical line
    wrapper.append("line").attr("class", "guide")
        .attr("x1", x).attr("y1", y)
        .attr("x2", x).attr("y2", scatterHeight-125)
        .style("stroke", color)
        .style("opacity",  0)
        .transition().duration(200)
        .style("opacity", 0.5);
    //horizontal line
    wrapper.append("line").attr("class", "guide")
        .attr("x1", x).attr("y1", y)
        .attr("x2", 30).attr("y2", y)
        .style("stroke", color)
        .style("opacity",  0)
        .transition().duration(200)
        .style("opacity", 1.0);

    //write values on axis
    //Value on the x-axis
    wrapper.append("text").attr("class", "guide legend")
        .attr("x", x)
        .attr("y", scatterHeight-120)
        .attr("dy", "0.71em")
        .style("color", "darkgrey")
        .style("opacity",  0)
        .style("text-anchor", "middle")
        .text(d3.format(".2s")(d.data.gdp) )
        .transition().duration(200)
        .style("opacity", 0.5);

    //Value on the y-axis
    wrapper.append("text").attr("class", "guide legend")
        .attr("x", 25).attr("y", y)
        .attr("dy", "0.32em")
        .style("color", "darkgrey")
        .style("background-color","white")
        .style("opacity",  0)
        .style("text-anchor", "end")
        .text( d.data.tb )
        .transition().duration(200)
        .style("opacity", 1.0);
}
var hideTooltip = function(d) {
    d3.selectAll(".guideWrapper").selectAll("line").remove();
    d3.selectAll(".guideWrapper").selectAll("text").remove();
    d3.select("#"+d.data.countryCode+"-tooltip").remove();
}
